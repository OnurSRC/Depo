# Prompt Quick Review

An inline prompt for first-pass review of prompt text against Opus 4.7 criteria. Use it when a deeper, multi-pass review is too heavy — a single model call produces a prioritized, remediation-ready finding list in one response.

**Companion to:** `prompt-authoring-guide.md` (the criteria).

-----

## When to use this vs. a full multi-pass review

|Situation                                                                     |Use                   |
|------------------------------------------------------------------------------|----------------------|
|Editing a prompt mid-flight; need a sanity check before committing            |Quick review          |
|Reviewing a small prompt (< 300 lines) or a single tool description           |Quick review          |
|Triaging unfamiliar prompts to decide whether deeper review is warranted      |Quick review          |
|Authoring a skill (SKILL.md + reference files + scripts)                      |Full multi-pass review|
|Need cross-lens consensus, severity calibration, integrated change proposals  |Full multi-pass review|
|Reviewing a collection of related prompts where cross-file consistency matters|Full multi-pass review|
|Preparing to ship a prompt to production                                      |Full multi-pass review|

**Rule of thumb:** run the quick review often; run a full multi-pass review at milestones.

-----

## What this finds

High-leverage defects across five dimensions of the eight-lens evaluator rubric:

- **Structural integrity** — dangling conditionals, broken file/section references, internal self-inconsistency.
- **Literal interpretation risk** — singular-object instructions where multiple referents exist, vague verbs on fragile operations, unstated generalizations, subjective conditions.
- **Attention economy** — emphasis overtriggering (CRITICAL/MUST saturation), unmotivated restrictions, maintainer prose that doesn’t serve execution.
- **Trigger specificity** — implicit tool or subagent triggers, unbounded exploratory verbs, unnamed decision points.
- **Output contract** — unspecified length, missing format schema or template, prefill dependence, negative-only style guidance.

## What this misses

Treat the quick review as first-pass, not final. It does **not** reliably catch:

- **Instruction clarity at fine grain** — subtle pronoun ambiguity, terminology drift across large bodies of text, passive-voice patterns that a dedicated IC evaluator catches.
- **Schema constraint legality (SCL)** — supported vs. unsupported JSON Schema keywords, Structured Outputs limits, hyper-literal numeric-constraint verification loops. The quick review flags *suspicion* of SCL issues but does not enumerate them; consult the SCL section of `prompt-authoring-guide.md` when Structured Outputs are in play.
- **Tool description quality (TDQ) at depth** — per-tool token-economy analysis, near-duplicate detection across a tool set. The quick review catches obvious TDQ issues (emphasis markers, missing when-to-use) on individual tool descriptions in scope, but does not audit a full tool catalog.
- **Cross-file consistency in collections** — use a multi-pass review with the full collection in scope.
- **Skill-specific structural issues** — SKILL.md frontmatter compliance, proportional-length heuristics, arguments-table-to-body mapping. A dedicated skill-targeted review is better for those.

When findings reference SCL or TDQ concerns, the prompt will tell you to dive deeper rather than trying to enumerate exhaustively.

-----

## How to use

1. Open the target prompt file and note its absolute path (or copy the prompt body if it’s embedded in another file).
2. Copy the prompt template below.
3. Replace `{{TARGET_PATH}}`, `{{TARGET_TYPE}}`, and `{{CONTEXT_NOTES}}` with values from your situation (see the table).
4. Send to Claude Opus 4.7 at `high` effort (default) or `xhigh` for a longer prompt with many referenced files.
5. Apply findings; re-run if you made non-trivial changes.

|Placeholder        |What to put                                                                                                                   |
|-------------------|------------------------------------------------------------------------------------------------------------------------------|
|`{{TARGET_PATH}}`  |Absolute path to the target prompt file (or `inline` if you paste the prompt body directly after the instruction).            |
|`{{TARGET_TYPE}}`  |One of: `skill-md`, `standalone-prompt`, `embedded-template`, `tool-description`. Shapes which lens weights the model applies.|
|`{{CONTEXT_NOTES}}`|One or two lines on how the prompt is executed (caller, effort level, consumers of its output). Leave as `none` if standalone.|

If you paste the prompt body inline instead of providing a path, replace the `Read [TARGET_PATH]` step with `The prompt text is quoted below.` and fence the body.

-----

## The prompt

Copy everything between the fences below, substitute placeholders, and send.

```
Review the prompt at {{TARGET_PATH}} for Claude Opus 4.7 readiness defects. Report findings a coding agent can apply without further research.

Target type: {{TARGET_TYPE}}
Execution context: {{CONTEXT_NOTES}}

Steps:
1. Read {{TARGET_PATH}}. If the prompt references other files with paths, read each referenced file once. Do not read files beyond one hop from the target.
2. Evaluate the target and each referenced file against all five dimensions below. Every referenced prompt template embedded in the target (fenced code blocks that dispatch to subagents, tool `description` fields) counts as prompt text and is in scope.
3. Produce findings as specified under Output.

Dimensions to evaluate (apply every dimension to every file in scope):

- Structural integrity. Every conditional ("if X", "when Y", "unless Z") has a defined branch for every path, including the else case. Every file path, section reference, and subagent dispatch target resolves. Output templates match generation instructions. Examples match stated rules. Argument defaults match body handling.
- Literal interpretation risk. Every instruction referring to a set uses an explicit universal quantifier ("every", "each", "all") when multiple referents exist. Fragile operations (file writes, destructive actions, output emission) use specific verbs naming the concrete action and object — not "handle", "process", "deal with", "manage". Generalizations state their scope explicitly rather than relying on the model inferring from a single illustrated case. Conditions are literally evaluable ("if the file exists") rather than subjective ("when appropriate").
- Attention economy. Emphasis markers (CRITICAL / MUST / ALWAYS / NEVER / ALL-CAPS) are rare enough that each carries signal — if you cannot name why each emphasized item is more consequential than the non-emphasized ones, the emphasis has been overspent. Restrictions on destructive or non-obvious behavior include a motivation clause. Prose that explains design rationale or maintainer intent is absent — every line drives execution. Tables dense enough to compete with prose for attention carry a "process every row" directive. Long prompts use section structure, numbered stages, and consistent headings so instructions are findable at the point of action — critical rules stated once in a top-of-prompt introduction without reinforcement are lost to drift. Negative instructions pair with a positive alternative in the same bullet, except for explicit 4.x-family anti-pattern suppression (e.g., preamble suppression).
- Trigger specificity. Every tool mention includes an explicit when-to-use condition. Every subagent dispatch states an explicit condition and whether dispatch is parallel or sequential. Parallel dispatch uses the canonical `<use_parallel_tool_calls>` snippet or an equivalent explicit imperative ("Dispatch all X in a single message as parallel foreground subagents"). Judgment steps carry a reasoning cue ("Think carefully about the tradeoffs before choosing"). Exploratory verbs ("investigate", "analyze comprehensively") are bounded by a count, a scope, or a declared effort level.
- Output contract. Response length is stated positively ("under 100 words", "two to three sentences per finding") rather than as a prohibition. Format is specified with a schema, template, or example — not inferred from context. No instruction relies on assistant-message prefilling to shape output. Voice guidance uses positive exemplars rather than prohibitions. Machine-consumed outputs reference Structured Outputs rather than prose schema description.

Output:

Respond directly without preamble — do not start with "Here is", "Based on my review", or similar. Structure the response as follows.

## Quick Review: {{TARGET_PATH}}

**Overall:** [one sentence, pick one: "ready", "minor fixes", "substantial revision needed", "fundamental rework needed"]

**Findings** (up to 12, ordered CRITICAL → HIGH → MEDIUM; stop at MEDIUM — do not emit LOW):

For every finding, use exactly this format:

### [SEVERITY] · [DIMENSION] · [LOCATION]
**Offending text:** "[verbatim quote, ≤25 words; use ellipsis if truncating]"
**Why on 4.7:** [one sentence citing the 4.7 behavior — literal execution, emphasis overtriggering, conservative tool defaults, native progress, prefill removal, tokenizer change, etc.]
**Remediation:** [the exact replacement text in a fenced block if over 10 words, or inline in backticks if shorter; include the full target text for any conditional branch, quantifier, or output-contract rewrite so a coding agent can apply the change by text substitution]

Where DIMENSION is one of: SI (structural integrity), LIR (literal interpretation), AE (attention economy), TS (trigger specificity), OC (output contract). Where LOCATION is `filename:line-range` when line numbers are available, or a heading path like `## Section > ### Subsection` otherwise.

Consolidation rule: if the same defect pattern appears more than twice, emit one finding with the primary instance in "Offending text" and a "Also at:" line listing up to five additional locations.

**Scope gaps** (always emit this section — set expectations for what this review did not cover):

- Instruction clarity at fine grain (pronoun ambiguity, terminology drift): [state whether the prompt appears likely to need deeper IC analysis — one sentence]
- Schema constraint legality: [if the target involves JSON Schema, Structured Outputs, tool definitions with strict mode, or prose numeric/length constraints, recommend a deeper multi-pass review or consulting the SCL section of `prompt-authoring-guide.md`; otherwise state "not applicable"]
- Tool description quality at depth: [if the target defines more than three tools or a tool-heavy orchestrator, recommend a deeper multi-pass review; otherwise state "not applicable"]
- Cross-file consistency: [if the target is part of a collection or pipeline and the companion files were not in the one-hop read set, name the unreviewed files]

Rules:
- Skip every finding that lacks a concrete, applicable remediation. A finding without a fix is noise.
- Quote offending text verbatim. Do not paraphrase the problem into a different phrase the user cannot grep for.
- Do not flag stylistic preferences. Flag behavioral risk on Opus 4.7.
- Do not recommend changes that only restate a dimension rule ("be more specific"). Remediations must contain the actual replacement.
- Do not speculate about the broader codebase or untouched files. Stay within the target and its one-hop references.
- If the target is already ready, emit fewer findings — do not pad to reach a count.
```

-----

## Interpreting the output

- **CRITICAL** findings cause wrong behavior on 4.7 in their domain — fix before running the prompt in production.
- **HIGH** findings cause wrong behavior sometimes, depending on effort level or input shape — fix before handing off.
- **MEDIUM** findings are recoverable defects — fix when touching adjacent code.
- **LOW** findings are intentionally excluded from this review. Run a deeper multi-pass review if you want them.

If the “Scope gaps” section recommends a deeper review, run one. If the remediation blocks quote replacement text, apply by direct substitution. If they describe an action (“add a when-to-use clause after line 42”), the remediation should specify the clause itself — reject findings where it does not.